#include <stdio.h>
#include<math.h>

int main()
{
    int n;
    float y=0, yd=0,inti ;
    float *y_1=&y;    //the reason i used pointer here is explained below
    float *yd_1=&yd;  //the reason i used pointer here is explained below
    printf("What is the degree of the polynomial? :");
    scanf("%d",&n);
    float p[n+1];
    for(int i=n; i>=0; i--){
        printf("Coefficient of degree(%d) :",i);
        scanf("%f",&p[i]);
    }
    printf("\nWhat is the initializing value? :");
    scanf("%f",&inti);
    for(int s=0; s<1000; s++){
       *y_1=0;
       *yd_1=0;
        for(int i=n; i>=0; i--){
            *y_1 += p[i]*pow(inti,i);   
        }
        for(int i=n; i>=0; i--){
            *yd_1 += i*p[i]*pow(inti,i-1);
        }
        float u= y/yd;
        inti =inti-u;
    }
    int unnecessary=y;
    if(unnecessary==0){
        printf("\nOne of the root obtained is %.6f  : y = %d",inti, unnecessary);
    }
    else{
        printf("\nNo result obtained: \n");
        printf("************************************************************\n");
        printf("Possible error may have occured: \n \n");
        printf("1. Your polynomial may not have any real root.\n");
        printf("2. Your initial value may have caused some problem.\n");
        printf("3. The strength of the loop may have been insufficient.\n");
    }
    return 0;
}

/*
i used pointer in the line 25 and 28 for placing value in y and yd 
because when used without pointer, after the loops of y and yd each ends its value returns to its initial value i.e 0
but using pointer i assign calculated value to their respective addresses so they wont go back to their initial value
*/




